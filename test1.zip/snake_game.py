import pygame
import random
import time
import math
from pygame import mixer

# Initialize Pygame
pygame.init()
mixer.init()

# Colors
WHITE = (255, 255, 255)
RED = (255, 50, 50)
GREEN = (50, 255, 50)
BLUE = (50, 50, 255)
BACKGROUND = (230, 230, 250)  # Light lavender background

# Game settings
WINDOW_SIZE = 800
GRID_SIZE = 20
GRID_COUNT = WINDOW_SIZE // GRID_SIZE

# Create window
screen = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
pygame.display.set_caption("Hungry Snake Adventure! 🐍")

class Snake:
    def __init__(self):
        self.length = 1
        self.positions = [(WINDOW_SIZE//2, WINDOW_SIZE//2)]
        self.direction = random.choice([UP, DOWN, LEFT, RIGHT])
        self.color = GREEN
        self.score = 0
        self.speed = 5
        self.food_collected = {}

    def get_head_position(self):
        return self.positions[0]

    def update(self):
        cur = self.get_head_position()
        x, y = self.direction
        new = ((cur[0] + (x*GRID_SIZE)) % WINDOW_SIZE, 
               (cur[1] + (y*GRID_SIZE)) % WINDOW_SIZE)
        
        if new in self.positions[3:]:
            return False  # Game Over
        
        self.positions.insert(0, new)
        if len(self.positions) > self.length:
            self.positions.pop()
        return True

    def draw(self, surface):
        for i, p in enumerate(self.positions):
            pygame.draw.rect(surface, self.color, 
                           (p[0], p[1], GRID_SIZE-1, GRID_SIZE-1))
            # Draw eyes on the head
            if i == 0:  # Head of the snake
                # Left eye
                pygame.draw.circle(surface, BLUE, 
                                 (p[0] + 5, p[1] + 5), 2)
                # Right eye
                pygame.draw.circle(surface, BLUE, 
                                 (p[0] + 15, p[1] + 5), 2)

class Food:
    def __init__(self):
        self.position = (0, 0)
        self.food_types = [
            {'color': (255, 0, 0), 'type': 'apple', 'points': 1},
            {'color': (255, 0, 127), 'type': 'strawberry', 'points': 2},
            {'color': (222, 184, 135), 'type': 'chicken', 'points': 3},
            {'color': (255, 165, 0), 'type': 'orange', 'points': 1},
            {'color': (255, 255, 0), 'type': 'banana', 'points': 2},
            {'color': (128, 0, 128), 'type': 'grapes', 'points': 3},
            {'color': (210, 180, 140), 'type': 'cookie', 'points': 4},
            {'color': (255, 192, 203), 'type': 'ice_cream', 'points': 5}
        ]
        self.current_food = random.choice(self.food_types)
        self.randomize_position()

    def draw(self, surface):
        x, y = self.position
        if self.current_food['type'] == 'apple':
            # Draw apple body
            pygame.draw.circle(surface, self.current_food['color'],
                             (x + GRID_SIZE//2, y + GRID_SIZE//2), 
                             GRID_SIZE//2 - 1)
            # Draw stem
            pygame.draw.rect(surface, (101, 67, 33),
                           (x + GRID_SIZE//2 - 1, y + 2, 3, 5))
            # Draw leaves (two leaves for better appearance)
            pygame.draw.ellipse(surface, (34, 139, 34),
                              (x + GRID_SIZE//2 + 2, y + 3, 6, 4))
            pygame.draw.ellipse(surface, (34, 139, 34),
                              (x + GRID_SIZE//2 - 7, y + 4, 6, 4))
            # Add shine detail
            pygame.draw.circle(surface, (255, 255, 255),
                             (x + GRID_SIZE//2 - 3, y + GRID_SIZE//2 - 3), 2)
        
        elif self.current_food['type'] == 'strawberry':
            # Draw strawberry body
            pygame.draw.polygon(surface, self.current_food['color'],
                              [(x + GRID_SIZE//2, y + 2),
                               (x + GRID_SIZE - 2, y + GRID_SIZE - 2),
                               (x + 2, y + GRID_SIZE - 2)])
            # Draw seeds (more organized pattern)
            for i in range(4):
                for j in range(4):
                    pygame.draw.circle(surface, (255, 255, 200),
                                     (x + 6 + i*4, y + 8 + j*4), 1)
            # Draw leaves at top
            pygame.draw.polygon(surface, (34, 139, 34),
                              [(x + GRID_SIZE//2, y + 2),
                               (x + GRID_SIZE//2 + 5, y - 2),
                               (x + GRID_SIZE//2 - 5, y - 2)])
            
        elif self.current_food['type'] == 'chicken':
            # Draw drumstick
            pygame.draw.circle(surface, self.current_food['color'],
                             (x + GRID_SIZE//2, y + GRID_SIZE//2), 
                             GRID_SIZE//2 - 1)
            # Draw stick part
            pygame.draw.rect(surface, self.current_food['color'],
                           (x + GRID_SIZE//2, y + GRID_SIZE//2,
                            GRID_SIZE//2, GRID_SIZE//3))
            # Draw bone end
            pygame.draw.circle(surface, (255, 255, 255),
                             (x + GRID_SIZE - 3, y + GRID_SIZE - 3), 4)
            # Add "cooked" effect
            pygame.draw.arc(surface, (139, 69, 19),
                          (x + 5, y + 5, GRID_SIZE-10, GRID_SIZE-10),
                          0, 3.14, 2)

        elif self.current_food['type'] == 'orange':
            # Draw orange body
            pygame.draw.circle(surface, self.current_food['color'],
                             (x + GRID_SIZE//2, y + GRID_SIZE//2), 
                             GRID_SIZE//2 - 1)
            # Draw leaf
            pygame.draw.ellipse(surface, (34, 139, 34),
                              (x + GRID_SIZE//2 - 2, y + 2, 6, 4))
            # Add segments
            for angle in range(0, 360, 45):
                end_x = x + GRID_SIZE//2 + int(8 * math.cos(math.radians(angle)))
                end_y = y + GRID_SIZE//2 + int(8 * math.sin(math.radians(angle)))
                pygame.draw.line(surface, (255, 140, 0),
                               (x + GRID_SIZE//2, y + GRID_SIZE//2),
                               (end_x, end_y), 1)

        elif self.current_food['type'] == 'banana':
            # Draw banana shape
            pygame.draw.arc(surface, self.current_food['color'],
                          (x, y, GRID_SIZE, GRID_SIZE),
                          0, 3.14, 5)
            pygame.draw.arc(surface, (255, 215, 0),  # Slightly darker for depth
                          (x + 2, y + 2, GRID_SIZE-4, GRID_SIZE-4),
                          0, 3.14, 5)

        elif self.current_food['type'] == 'grapes':
            # Draw multiple grape circles
            for i in range(3):
                for j in range(3):
                    if (i+j) % 2 == 0:
                        pygame.draw.circle(surface, self.current_food['color'],
                                         (x + 6 + i*5, y + 6 + j*5), 3)
            # Add leaves
            pygame.draw.polygon(surface, (34, 139, 34),
                              [(x + GRID_SIZE//2, y),
                               (x + GRID_SIZE//2 + 4, y + 4),
                               (x + GRID_SIZE//2 - 4, y + 4)])

        elif self.current_food['type'] == 'cookie':
            # Draw cookie base
            pygame.draw.circle(surface, self.current_food['color'],
                             (x + GRID_SIZE//2, y + GRID_SIZE//2), 
                             GRID_SIZE//2 - 1)
            # Add chocolate chips
            for i in range(5):
                chip_x = x + 5 + random.randint(0, GRID_SIZE-10)
                chip_y = y + 5 + random.randint(0, GRID_SIZE-10)
                pygame.draw.circle(surface, (60, 30, 10),
                                 (chip_x, chip_y), 2)

        elif self.current_food['type'] == 'ice_cream':
            # Draw cone
            pygame.draw.polygon(surface, (222, 184, 135),
                              [(x + GRID_SIZE//2, y + GRID_SIZE),
                               (x + 2, y + GRID_SIZE//2),
                               (x + GRID_SIZE - 2, y + GRID_SIZE//2)])
            # Draw ice cream scoops
            pygame.draw.circle(surface, self.current_food['color'],
                             (x + GRID_SIZE//2, y + GRID_SIZE//3), 
                             GRID_SIZE//3)
            # Add sprinkles
            for _ in range(5):
                sprinkle_x = x + GRID_SIZE//2 + random.randint(-5, 5)
                sprinkle_y = y + GRID_SIZE//3 + random.randint(-5, 5)
                pygame.draw.circle(surface, (255, 255, 0),
                                 (sprinkle_x, sprinkle_y), 1)

    def randomize_position(self):
        self.position = (random.randint(0, GRID_COUNT-1) * GRID_SIZE,
                        random.randint(0, GRID_COUNT-1) * GRID_SIZE)
        self.current_food = random.choice(self.food_types)

class Wall:
    def __init__(self):
        # Make walls rectangular
        self.width = GRID_SIZE * 3  # 3 grid cells wide
        self.height = GRID_SIZE     # 1 grid cell tall
        self.position = (random.randint(5, GRID_COUNT-8) * GRID_SIZE,
                        random.randint(5, GRID_COUNT-5) * GRID_SIZE)
        self.color = (139, 69, 19)  # Brown color for walls
        self.direction = random.choice([UP, DOWN, LEFT, RIGHT])
        self.speed = 0.5

    def update(self):
        x, y = self.direction
        new_x = (self.position[0] + (x*self.speed)) % (WINDOW_SIZE - self.width)
        new_y = (self.position[1] + (y*self.speed)) % (WINDOW_SIZE - self.height)
        self.position = (new_x, new_y)

    def draw(self, surface):
        pygame.draw.rect(surface, self.color,
                        (self.position[0], self.position[1], 
                         self.width, self.height))
        # Add brick pattern
        for i in range(3):
            x = self.position[0] + (i * GRID_SIZE)
            pygame.draw.rect(surface, (101, 67, 33),  # Darker brown
                           (x, self.position[1], 
                            GRID_SIZE-1, self.height-1), 1)

def show_game_over(surface, score, food_collected):
    running = True
    surface.fill(BACKGROUND)
    
    # Show game over and score
    font_large = pygame.font.Font(None, 64)
    font_small = pygame.font.Font(None, 36)
    
    text = font_large.render('Game Over!', True, (0, 0, 0))
    text_rect = text.get_rect()
    text_rect.centerx = WINDOW_SIZE//2
    text_rect.top = WINDOW_SIZE//4
    surface.blit(text, text_rect)
    
    score_text = font_large.render(f'Score: {score}', True, (0, 0, 0))
    score_rect = score_text.get_rect()
    score_rect.centerx = WINDOW_SIZE//2
    score_rect.top = text_rect.bottom + 20
    surface.blit(score_text, score_rect)
    
    # Create restart button
    button_color = (50, 200, 50)
    button_rect = pygame.Rect(WINDOW_SIZE//2 - 60, WINDOW_SIZE - 100, 120, 40)
    
    # Show food collection summary with icons
    y_offset = score_rect.bottom + 40
    title = font_small.render('Food Collected:', True, (0, 0, 0))
    surface.blit(title, (WINDOW_SIZE//4, y_offset))
    
    # Create a temporary Food object to draw food icons
    temp_food = Food()
    y_offset += 40
    x_offset = WINDOW_SIZE//4

    for food_type, count in food_collected.items():
        # Draw food icon
        temp_food.current_food = next(f for f in temp_food.food_types 
                                    if f['type'] == food_type)
        temp_food.position = (x_offset, y_offset - GRID_SIZE//2)
        temp_food.draw(surface)
        
        # Draw food name and count
        food_name = food_type.replace('_', ' ').title()  # Format name nicely
        food_text = font_small.render(f"{food_name} x {count}", True, (0, 0, 0))
        surface.blit(food_text, (x_offset + GRID_SIZE + 10, y_offset))
        
        y_offset += 40

    while running:
        # Draw restart button
        pygame.draw.rect(surface, button_color, button_rect)
        pygame.draw.rect(surface, (0, 100, 0), button_rect, 2)  # border
        restart_text = font_small.render('Restart', True, (255, 255, 255))
        text_rect = restart_text.get_rect(center=button_rect.center)
        surface.blit(restart_text, text_rect)
        
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if button_rect.collidepoint(event.pos):
                    return True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return True

    return False

def main():
    running = True
    while running:
        clock = pygame.time.Clock()
        last_update = time.time()
        snake = Snake()
        food = Food()
        walls = [Wall() for _ in range(3)]
        
        # Load and play background music
        try:
            pygame.mixer.music.load("background_music.mp3")
            pygame.mixer.music.play(-1)  # -1 means loop indefinitely
        except:
            print("Background music file not found!")

        # Load sound effects
        try:
            eat_sound = pygame.mixer.Sound("eat.wav")
        except:
            eat_sound = None
            print("Eat sound effect not found!")

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP and snake.direction != DOWN:
                        snake.direction = UP
                    elif event.key == pygame.K_DOWN and snake.direction != UP:
                        snake.direction = DOWN
                    elif event.key == pygame.K_LEFT and snake.direction != RIGHT:
                        snake.direction = LEFT
                    elif event.key == pygame.K_RIGHT and snake.direction != LEFT:
                        snake.direction = RIGHT

            # Update snake position
            if time.time() - last_update > 1/snake.speed:
                # Update walls
                for wall in walls:
                    wall.update()
                
                # Check wall collisions
                snake_head = snake.get_head_position()
                for wall in walls:
                    wall_rect = pygame.Rect(wall.position[0], wall.position[1], 
                                          wall.width, wall.height)
                    snake_rect = pygame.Rect(snake_head[0], snake_head[1], 
                                           GRID_SIZE-1, GRID_SIZE-1)
                    if wall_rect.colliderect(snake_rect):
                        running = show_game_over(screen, snake.score, snake.food_collected)
                        if running:
                            break
                        return
                
                if not snake.update():
                    running = show_game_over(screen, snake.score, snake.food_collected)
                    if running:
                        break
                    return
                last_update = time.time()

            # Check if snake ate the food
            if snake.get_head_position() == food.position:
                food_type = food.current_food['type']
                if food_type not in snake.food_collected:
                    snake.food_collected[food_type] = 0
                snake.food_collected[food_type] += 1
                snake.length += 1
                snake.score += 1
                food.randomize_position()
                if eat_sound:
                    eat_sound.play()
                # Increase speed every 5 points
                if snake.score % 5 == 0:
                    snake.speed += 1

            screen.fill(BACKGROUND)
            snake.draw(screen)
            food.draw(screen)
            # Draw walls
            for wall in walls:
                wall.draw(screen)
            draw_score(screen, snake.score)
            pygame.display.update()
            clock.tick(30)

            if not running:
                break

def draw_score(surface, score):
    font = pygame.font.Font(None, 36)
    text = font.render(f'Score: {score}', True, (0, 0, 0))
    surface.blit(text, (10, 10))

# Directions
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

if __name__ == "__main__":
    main() 